// Copyright © 2020 Apple Inc. All rights reserved.

#import <Foundation/Foundation.h>

//! Project version number for CoreTransferable.
FOUNDATION_EXPORT double CoreTransferableVersionNumber;
