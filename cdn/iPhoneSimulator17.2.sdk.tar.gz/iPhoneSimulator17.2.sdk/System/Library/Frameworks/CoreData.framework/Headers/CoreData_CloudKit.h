/*
    CoreData_CloudKit.h
    Core Data
    Copyright (c) 2021-2023, Apple Inc.
    All rights reserved.
*/


#import <CoreData/NSPersistentCloudKitContainer_Sharing.h>

