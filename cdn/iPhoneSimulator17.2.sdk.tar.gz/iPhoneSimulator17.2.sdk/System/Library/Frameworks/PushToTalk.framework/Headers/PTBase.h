//
//  PTBase.h
//  PushToTalk
//
//  Copyright © 2022 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef __cplusplus
#define PT_EXTERN extern "C" __attribute__((visibility("default")))
#else
#define PT_EXTERN extern __attribute__((visibility("default")))
#endif

