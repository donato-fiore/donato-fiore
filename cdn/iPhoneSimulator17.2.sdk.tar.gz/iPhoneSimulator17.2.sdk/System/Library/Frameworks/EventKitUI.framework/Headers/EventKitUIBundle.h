//
//  EventKitUIBundle.h
//  EventKitUI
//
//  Copyright 2008 Apple Computer, Inc. All rights reserved.
//

#import <EventKitUI/EventKitUIDefines.h>
#import <Foundation/Foundation.h>

EVENTKITUI_EXTERN NSBundle *EventKitUIBundle(void);

